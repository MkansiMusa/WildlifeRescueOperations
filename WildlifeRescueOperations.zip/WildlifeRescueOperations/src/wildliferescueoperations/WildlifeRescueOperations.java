package wildliferescueoperations;

import java.util.Scanner;

public class WildlifeRescueOperations {

    private static final Scanner scanner = new Scanner(System.in);
    private static final RescueManager manager = new RescueManager();

    public static void main(String[] args) {

        int option;

        do {
            displayMenu();

            option = readInt("Select an option: ");

            switch (option) {

                case 1:
                    createRescueCase();
                    break;

                case 2:
                    searchRescueCase();
                    break;

                case 3:
                    updateRescueStatus();
                    break;

                case 4:
                    displayAllRescueCases();
                    break;

                case 5:
                    generateReport();
                    break;

                case 6:
                    System.out.println();
                    System.out.println(
                            "Thank you for using the Wildlife Rescue Operations System."
                    );
                    break;

                default:
                    System.out.println();
                    System.out.println(
                            "Invalid option. Please select a number from 1 to 6."
                    );
            }

        } while (option != 6);

        scanner.close();
    }

    // ==========================================
    // MAIN MENU
    // ==========================================

    private static void displayMenu() {

        System.out.println();
        System.out.println("==============================================");
        System.out.println("      WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("==============================================");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
        System.out.println("==============================================");
    }

    // ==========================================
    // CREATE RESCUE CASE
    // ==========================================

    private static void createRescueCase() {

        System.out.println();
        System.out.println("========== CREATE RESCUE CASE ==========");

        String id = readNonBlank("Rescue Case ID: ");

        // Check for duplicate ID
        if (manager.findRescueCase(id) != null) {

            System.out.println();
            System.out.println(
                    "Error: This Rescue Case ID already exists."
            );

            return;
        }

        String animalName =
                readNonBlank("Animal Name: ");

        String species =
                readNonBlank("Species: ");

        String location =
                readNonBlank("Rescue Location: ");

        String ranger =
                readNonBlank("Assigned Ranger: ");

        int days =
                readPositiveInt("Number of Rescue Days: ");

        double dailyCost =
                readPositiveDouble("Daily Care Cost: R");

        // ------------------------------------------
        // SELECT RESCUE TYPE
        // ------------------------------------------

        System.out.println();
        System.out.println("Select Rescue Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");

        int type =
                readInt("Enter rescue type: ");

        RescueCase rescueCase = null;

        switch (type) {

            // ======================================
            // INJURED ANIMAL
            // ======================================

            case 1:

                String injury =
                        readNonBlank("Injury Description: ");

                double veterinaryCost =
                        readPositiveDouble(
                                "Veterinary Treatment Cost: R"
                        );

                boolean surgery =
                        readYesNo(
                                "Surgery Required? (Y/N): "
                        );

                rescueCase =
                        new InjuredAnimalRescue(
                                id,
                                animalName,
                                species,
                                location,
                                ranger,
                                days,
                                dailyCost,
                                injury,
                                veterinaryCost,
                                surgery
                        );

                break;

            // ======================================
            // ORPHANED ANIMAL
            // ======================================

            case 2:

                int age =
                        readNonNegativeInt(
                                "Estimated Age (Months): "
                        );

                double feedingCost =
                        readPositiveDouble(
                                "Feeding Cost: R"
                        );

                boolean foster =
                        readYesNo(
                                "Foster Care Required? (Y/N): "
                        );

                rescueCase =
                        new OrphanedAnimalRescue(
                                id,
                                animalName,
                                species,
                                location,
                                ranger,
                                days,
                                dailyCost,
                                age,
                                feedingCost,
                                foster
                        );

                break;

            // ======================================
            // ENDANGERED SPECIES
            // ======================================

            case 3:

                String classification =
                        readNonBlank(
                                "Conservation Classification: "
                        );

                double securityCost =
                        readPositiveDouble(
                                "Security Cost: R"
                        );

                boolean specialist =
                        readYesNo(
                                "Specialist Team Required? (Y/N): "
                        );

                rescueCase =
                        new EndangeredSpeciesRescue(
                                id,
                                animalName,
                                species,
                                location,
                                ranger,
                                days,
                                dailyCost,
                                classification,
                                securityCost,
                                specialist
                        );

                break;

            default:

                System.out.println();
                System.out.println(
                        "Invalid rescue type."
                );

                return;
        }

        // ------------------------------------------
        // ADD RESCUE CASE
        // ------------------------------------------

        if (manager.addRescueCase(rescueCase)) {

            System.out.println();
            System.out.println(
                    "Rescue case successfully created."
            );

            System.out.println(
                    "Rescue Type: "
                    + rescueCase.getRescueType()
            );

            System.out.println(
                    "Priority: "
                    + rescueCase.determinePriority()
            );

            System.out.println(
                    "Total Cost: R"
                    + String.format(
                            "%.2f",
                            rescueCase.calculateTotalRescueCost()
                    )
            );

        } else {

            System.out.println();
            System.out.println(
                    "Unable to create rescue case."
            );
        }
    }

    // ==========================================
    // SEARCH RESCUE CASE
    // ==========================================

    private static void searchRescueCase() {

        System.out.println();
        System.out.println("========== SEARCH RESCUE CASE ==========");

        String id =
                readNonBlank("Enter Rescue Case ID: ");

        RescueCase rescueCase =
                manager.findRescueCase(id);

        if (rescueCase == null) {

            System.out.println();
            System.out.println(
                    "Rescue case not found."
            );

        } else {

            displayRescueCase(rescueCase);
        }
    }

    // ==========================================
    // UPDATE RESCUE STATUS
    // ==========================================

    private static void updateRescueStatus() {

        System.out.println();
        System.out.println("========== UPDATE RESCUE STATUS ==========");

        String id =
                readNonBlank("Enter Rescue Case ID: ");

        RescueCase rescueCase =
                manager.findRescueCase(id);

        if (rescueCase == null) {

            System.out.println();
            System.out.println(
                    "Rescue case not found."
            );

            return;
        }

        System.out.println();
        System.out.println("1. Start Rescue");
        System.out.println("2. Complete Rescue");
        System.out.println("3. Set Custom Status");

        int option =
                readInt("Select option: ");

        switch (option) {

            case 1:

                rescueCase.startRescue();

                System.out.println(
                        "Rescue operation started."
                );

                break;

            case 2:

                rescueCase.completeRescue();

                System.out.println(
                        "Rescue operation completed."
                );

                break;

            case 3:

                String status =
                        readNonBlank(
                                "Enter new status: "
                        );

                rescueCase.setCurrentRescueStatus(status);

                System.out.println(
                        "Status updated successfully."
                );

                break;

            default:

                System.out.println(
                        "Invalid option."
                );
        }
    }

    // ==========================================
    // DISPLAY ALL RESCUE CASES
    // ==========================================

    private static void displayAllRescueCases() {

        System.out.println();
        System.out.println("========== ALL RESCUE CASES ==========");

        if (manager.getRescueCases().isEmpty()) {

            System.out.println(
                    "No rescue cases available."
            );

            return;
        }

        for (RescueCase rescueCase :
                manager.getRescueCases()) {

            displayRescueCase(rescueCase);

            System.out.println(
                    "----------------------------------------------"
            );
        }
    }

    // ==========================================
    // DISPLAY ONE RESCUE CASE
    // ==========================================

    private static void displayRescueCase(
            RescueCase rescueCase) {

        System.out.println();
        System.out.println(
                "----------------------------------------------"
        );

        System.out.println(
                "Case ID: "
                + rescueCase.getRescueCaseId()
        );

        System.out.println(
                "Animal Name: "
                + rescueCase.getAnimalName()
        );

        System.out.println(
                "Rescue Type: "
                + rescueCase.getRescueType()
        );

        System.out.println(
                "Species: "
                + rescueCase.getSpecies()
        );

        System.out.println(
                "Rescue Location: "
                + rescueCase.getRescueLocation()
        );

        System.out.println(
                "Assigned Ranger: "
                + rescueCase.getAssignedRanger()
        );

        System.out.println(
                "Rescue Days: "
                + rescueCase.getNumberOfRescueDays()
        );

        System.out.println(
                "Daily Care Cost: R"
                + String.format(
                        "%.2f",
                        rescueCase.getDailyCareCost()
                )
        );

        System.out.println(
                "Priority: "
                + rescueCase.determinePriority()
        );

        System.out.println(
                "Status: "
                + rescueCase.getCurrentRescueStatus()
        );

        System.out.println(
                "Total Cost: R"
                + String.format(
                        "%.2f",
                        rescueCase.calculateTotalRescueCost()
                )
        );

        System.out.println();
        System.out.println("Specific Information:");

        System.out.println(
                rescueCase.getSpecificInformation()
        );

        System.out.println(
                "----------------------------------------------"
        );
    }

    // ==========================================
    // RESCUE REPORT
    // ==========================================

    private static void generateReport() {

        System.out.println();
        System.out.println("================================================");
        System.out.println("              WILDLIFE RESCUE REPORT");
        System.out.println("================================================");

        if (manager.getRescueCases().isEmpty()) {

            System.out.println(
                    "No rescue cases available."
            );

            return;
        }

        for (RescueCase rescueCase :
                manager.getRescueCases()) {

            System.out.println();

            System.out.println(
                    "Case ID       : "
                    + rescueCase.getRescueCaseId()
            );

            System.out.println(
                    "Rescue Type   : "
                    + rescueCase.getRescueType()
            );

            System.out.println(
                    "Species       : "
                    + rescueCase.getSpecies()
            );

            System.out.println(
                    "Location      : "
                    + rescueCase.getRescueLocation()
            );

            System.out.println(
                    "Ranger        : "
                    + rescueCase.getAssignedRanger()
            );

            System.out.println(
                    "Priority      : "
                    + rescueCase.determinePriority()
            );

            System.out.println(
                    "Status        : "
                    + rescueCase.getCurrentRescueStatus()
            );

            System.out.println(
                    "Total Cost    : R"
                    + String.format(
                            "%.2f",
                            rescueCase.calculateTotalRescueCost()
                    )
            );

            System.out.println(
                    "----------------------------------------------"
            );
        }

        System.out.println();

        System.out.println(
                "Total Rescue Cases: "
                + manager.getNumberOfRescueCases()
        );

        System.out.println(
                "Total Estimated Rescue Cost: R"
                + String.format(
                        "%.2f",
                        manager.calculateTotalEstimatedCost()
                )
        );

        System.out.println(
                "================================================"
        );
    }

    // ==========================================
    // INPUT VALIDATION
    // ==========================================

    private static String readNonBlank(String message) {

        while (true) {

            System.out.print(message);

            String input =
                    scanner.nextLine().trim();

            if (!input.isEmpty()) {
                return input;
            }

            System.out.println(
                    "Input cannot be blank. Please try again."
            );
        }
    }

    private static int readInt(String message) {

        while (true) {

            try {

                System.out.print(message);

                int value =
                        Integer.parseInt(
                                scanner.nextLine()
                        );

                return value;

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid number."
                );
            }
        }
    }

    private static int readPositiveInt(
            String message) {

        while (true) {

            int value =
                    readInt(message);

            if (value > 0) {
                return value;
            }

            System.out.println(
                    "Value must be greater than zero."
            );
        }
    }

    private static int readNonNegativeInt(
            String message) {

        while (true) {

            int value =
                    readInt(message);

            if (value >= 0) {
                return value;
            }

            System.out.println(
                    "Value cannot be negative."
            );
        }
    }

    private static double readPositiveDouble(
            String message) {

        while (true) {

            try {

                System.out.print(message);

                double value =
                        Double.parseDouble(
                                scanner.nextLine()
                        );

                if (value > 0) {
                    return value;
                }

                System.out.println(
                        "Value must be greater than zero."
                );

            } catch (NumberFormatException e) {

                System.out.println(
                        "Please enter a valid amount."
                );
            }
        }
    }

    private static boolean readYesNo(
            String message) {

        while (true) {

            System.out.print(message);

            String input =
                    scanner.nextLine().trim();

            if (input.equalsIgnoreCase("Y")) {
                return true;
            }

            if (input.equalsIgnoreCase("N")) {
                return false;
            }

            System.out.println(
                    "Please enter Y or N."
            );
        }
    }
}