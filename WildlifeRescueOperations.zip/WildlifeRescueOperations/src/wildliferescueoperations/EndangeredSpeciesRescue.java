package wildliferescueoperations;

public class EndangeredSpeciesRescue extends RescueCase {

    // Endangered species specific information
    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    // Constructor
    public EndangeredSpeciesRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String conservationClassification,
            double securityCost,
            boolean specialistTeamRequired) {

        // Call the parent class constructor
        super(
                rescueCaseId,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost
        );

        this.conservationClassification =
                conservationClassification;

        this.securityCost = securityCost;

        this.specialistTeamRequired =
                specialistTeamRequired;
    }

    // ==============================
    // GETTERS
    // ==============================

    public String getConservationClassification() {
        return conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }

    // ==============================
    // TOTAL RESCUE COST
    // ==============================

    @Override
    public double calculateTotalRescueCost() {

        double totalCost =
                calculateBasicCareCost()
                + securityCost;

        // Specialist team adds R8 000
        if (specialistTeamRequired) {
            totalCost += 8000;
        }

        return totalCost;
    }

    // ==============================
    // RESCUE PRIORITY
    // ==============================

    @Override
    public String determinePriority() {

        if (specialistTeamRequired) {
            return "Critical";
        }

        return "High";
    }

    // ==============================
    // RESCUE TYPE
    // ==============================

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    // ==============================
    // SPECIFIC INFORMATION
    // ==============================

    @Override
    public String getSpecificInformation() {

        return "Conservation Classification: "
                + conservationClassification
                + "\nSecurity Cost: R"
                + String.format("%.2f", securityCost)
                + "\nSpecialist Team Required: "
                + (specialistTeamRequired ? "Yes" : "No");
    }
}