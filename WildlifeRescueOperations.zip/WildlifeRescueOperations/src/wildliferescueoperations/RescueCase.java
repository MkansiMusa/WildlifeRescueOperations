package wildliferescueoperations;

public abstract class RescueCase implements RescueOperations {

    // Common rescue case information
    private String rescueCaseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private String currentRescueStatus;

    // Constructor
    public RescueCase(String rescueCaseId,
                      String animalName,
                      String species,
                      String rescueLocation,
                      String assignedRanger,
                      int numberOfRescueDays,
                      double dailyCareCost) {

        this.rescueCaseId = rescueCaseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;

        // Every new rescue starts as Pending
        this.currentRescueStatus = "Pending";
    }

    // ==============================
    // GETTERS
    // ==============================

    public String getRescueCaseId() {
        return rescueCaseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public String getCurrentRescueStatus() {
        return currentRescueStatus;
    }

    // ==============================
    // SETTERS
    // ==============================

    public void setCurrentRescueStatus(String currentRescueStatus) {
        this.currentRescueStatus = currentRescueStatus;
    }

    public void setNumberOfRescueDays(int numberOfRescueDays) {
        this.numberOfRescueDays = numberOfRescueDays;
    }

    public void setDailyCareCost(double dailyCareCost) {
        this.dailyCareCost = dailyCareCost;
    }

    // ==============================
    // COMMON COST CALCULATION
    // ==============================

    protected double calculateBasicCareCost() {
        return numberOfRescueDays * dailyCareCost;
    }

    // ==============================
    // RESCUE OPERATIONS
    // ==============================

    @Override
    public void startRescue() {
        currentRescueStatus = "Rescue in Progress";
    }

    @Override
    public void completeRescue() {
        currentRescueStatus = "Completed";
    }

    @Override
    public String generateSummary() {

        return "Case ID: " + rescueCaseId
                + "\nRescue Type: " + getRescueType()
                + "\nSpecies: " + species
                + "\nAssigned Ranger: " + assignedRanger
                + "\nRescue Priority: " + determinePriority()
                + "\nCurrent Status: " + currentRescueStatus
                + "\nTotal Rescue Cost: R"
                + String.format("%.2f", calculateTotalRescueCost());
    }

    // ==============================
    // ABSTRACT METHODS
    // ==============================

    public abstract double calculateTotalRescueCost();

    public abstract String determinePriority();

    public abstract String getRescueType();

    public abstract String getSpecificInformation();
}