package wildliferescueoperations;

import java.util.ArrayList;

public class RescueManager {

    // Store all rescue cases in an ArrayList
    private ArrayList<RescueCase> rescueCases;

    // Constructor
    public RescueManager() {
        rescueCases = new ArrayList<>();
    }

    // ==============================
    // ADD RESCUE CASE
    // ==============================

    public boolean addRescueCase(RescueCase rescueCase) {

        // Prevent null rescue cases
        if (rescueCase == null) {
            return false;
        }

        // Prevent duplicate rescue case IDs
        if (findRescueCase(rescueCase.getRescueCaseId()) != null) {
            return false;
        }

        rescueCases.add(rescueCase);

        return true;
    }

    // ==============================
    // SEARCH RESCUE CASE
    // ==============================

    public RescueCase findRescueCase(String rescueCaseId) {

        for (RescueCase rescueCase : rescueCases) {

            if (rescueCase.getRescueCaseId()
                    .equalsIgnoreCase(rescueCaseId)) {

                return rescueCase;
            }
        }

        return null;
    }

    // ==============================
    // UPDATE RESCUE STATUS
    // ==============================

    public boolean updateRescueStatus(
            String rescueCaseId,
            String newStatus) {

        RescueCase rescueCase =
                findRescueCase(rescueCaseId);

        if (rescueCase == null) {
            return false;
        }

        rescueCase.setCurrentRescueStatus(newStatus);

        return true;
    }

    // ==============================
    // GET ALL RESCUE CASES
    // ==============================

    public ArrayList<RescueCase> getRescueCases() {
        return rescueCases;
    }

    // ==============================
    // NUMBER OF RESCUE CASES
    // ==============================

    public int getNumberOfRescueCases() {
        return rescueCases.size();
    }

    // ==============================
    // CALCULATE TOTAL ESTIMATED COST
    // ==============================

    public double calculateTotalEstimatedCost() {

        double total = 0;

        for (RescueCase rescueCase : rescueCases) {

            total += rescueCase.calculateTotalRescueCost();
        }

        return total;
    }
}