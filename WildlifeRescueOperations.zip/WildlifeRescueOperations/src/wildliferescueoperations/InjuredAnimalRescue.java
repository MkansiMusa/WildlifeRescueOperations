package wildliferescueoperations;

public class InjuredAnimalRescue extends RescueCase {

    // Injured animal specific information
    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    // Constructor
    public InjuredAnimalRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            String injuryDescription,
            double veterinaryTreatmentCost,
            boolean surgeryRequired) {

        // Call the parent class constructor
        super(
                rescueCaseId,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost
        );

        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    // ==============================
    // GETTERS
    // ==============================

    public String getInjuryDescription() {
        return injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    // ==============================
    // TOTAL RESCUE COST
    // ==============================

    @Override
    public double calculateTotalRescueCost() {

        double totalCost =
                calculateBasicCareCost()
                + veterinaryTreatmentCost;

        // Surgery adds R5 000
        if (surgeryRequired) {
            totalCost += 5000;
        }

        return totalCost;
    }

    // ==============================
    // RESCUE PRIORITY
    // ==============================

    @Override
    public String determinePriority() {

        if (surgeryRequired) {
            return "Critical";
        }

        return "High";
    }

    // ==============================
    // RESCUE TYPE
    // ==============================

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    // ==============================
    // SPECIFIC INFORMATION
    // ==============================

    @Override
    public String getSpecificInformation() {

        return "Injury Description: "
                + injuryDescription
                + "\nVeterinary Treatment Cost: R"
                + String.format("%.2f", veterinaryTreatmentCost)
                + "\nSurgery Required: "
                + (surgeryRequired ? "Yes" : "No");
    }
}