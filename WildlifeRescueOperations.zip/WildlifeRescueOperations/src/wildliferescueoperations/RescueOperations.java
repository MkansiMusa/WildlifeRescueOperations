package wildliferescueoperations;

public interface RescueOperations {

    void startRescue();

    void completeRescue();

    String generateSummary();
}