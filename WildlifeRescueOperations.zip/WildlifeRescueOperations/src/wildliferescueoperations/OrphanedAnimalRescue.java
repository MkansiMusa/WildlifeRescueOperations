package wildliferescueoperations;

public class OrphanedAnimalRescue extends RescueCase {

    // Orphaned animal specific information
    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    // Constructor
    public OrphanedAnimalRescue(
            String rescueCaseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int numberOfRescueDays,
            double dailyCareCost,
            int estimatedAgeMonths,
            double feedingCost,
            boolean fosterCareRequired) {

        // Call the parent class constructor
        super(
                rescueCaseId,
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                numberOfRescueDays,
                dailyCareCost
        );

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    // ==============================
    // GETTERS
    // ==============================

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }

    // ==============================
    // TOTAL RESCUE COST
    // ==============================

    @Override
    public double calculateTotalRescueCost() {

        double totalCost =
                calculateBasicCareCost()
                + feedingCost;

        // Foster care adds R2 500
        if (fosterCareRequired) {
            totalCost += 2500;
        }

        return totalCost;
    }

    // ==============================
    // RESCUE PRIORITY
    // ==============================

    @Override
    public String determinePriority() {

        if (estimatedAgeMonths <= 6) {
            return "Critical";
        }

        return "High";
    }

    // ==============================
    // RESCUE TYPE
    // ==============================

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    // ==============================
    // SPECIFIC INFORMATION
    // ==============================

    @Override
    public String getSpecificInformation() {

        return "Estimated Age: "
                + estimatedAgeMonths
                + " months"
                + "\nFeeding Cost: R"
                + String.format("%.2f", feedingCost)
                + "\nFoster Care Required: "
                + (fosterCareRequired ? "Yes" : "No");
    }
}